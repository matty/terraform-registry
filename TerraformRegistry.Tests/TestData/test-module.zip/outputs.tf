output "number" {
  value       = random_integer.priority.result
  description = "The generated random priority number."
}